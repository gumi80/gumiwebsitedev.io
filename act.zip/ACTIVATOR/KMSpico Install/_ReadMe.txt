Instructions:
1) Stop the application if started
2) Disable your antivirus
3) Install application using provided installer and do not reboot
4) Run Key file
DONE!
 

